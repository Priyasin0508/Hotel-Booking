# Hotel-Management-system
Technology/Language used:-
  -	HTML
  -	CSS
  -	PHP
  -	JAVASCRIPT
```
HTML: We can create your own Website.
CSS: CSS is a language that describes the style of an HTML document.
PHP: PHP is a server scripting language, and a powerful tool for making dynamic and interactive Web pages.
JAVASCRIPT: JavaScript is the programming language of HTML and the Web.
```
```
This is an implementation of Hotel Management System using various method describes above to get the better and efficient Outlook.
```
The code was inspired by using the basic's and development activity:
(https://www.w3schools.com/)
